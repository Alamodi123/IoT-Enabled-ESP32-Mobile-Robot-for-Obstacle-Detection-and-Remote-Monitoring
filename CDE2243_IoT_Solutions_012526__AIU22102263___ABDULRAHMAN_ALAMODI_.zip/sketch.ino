#include <WiFi.h>
#include <HTTPClient.h>

// Ultrasonic sensor pins (HC-SR04)
#define TRIG_PIN 5
#define ECHO_PIN 18
#define SAFE_DISTANCE 20   // cm threshold for obstacle avoidance

// LEDs to simulate motor states 
#define LED_FORWARD 26
#define LED_STOP    27
#define LED_WARNING    14

// Battery monitoring 
#define BAT_ADC 34


//               WIFI + CLOUD SETTINGS

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ThingSpeak HTTP endpoint
const char* server = "http://api.thingspeak.com/update";
String apiKey = "V4EI56BI05FAX1RG";

// ThingSpeak rate limit: send at most once every 15 seconds
unsigned long lastSend = 0;
const unsigned long sendInterval = 15000; // ms

//               SENSOR FUNCTIONS

// Read distance in cm using HC-SR04
float readDistanceCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Measure echo pulse width (timeout 30ms)
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1; // no reading / timeout 
  return (duration * 0.034f) / 2.0f; // Convert microseconds to cm:
}

// Read battery level (0–100%) using potentiometer 
int readBatteryPercent() {
  // Read raw ADC value (0..4095 because ESP32 is 12-bit ADC)
  int adc = analogRead(BAT_ADC);

  // Convert to voltage relative to 3.3V 
  float v = (adc / 4095.0f) * 3.3f;

  // Map 0..3.3V to 0..100%
  int pct = (int)((v / 3.3f) * 100.0f);

  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;

  return pct;
}

//                  ACTUATION (LED STATES)


// Forward state: green ON, others OFF
void setForward() {
  digitalWrite(LED_FORWARD, HIGH);
  digitalWrite(LED_STOP, LOW);
  digitalWrite(LED_WARNING, LOW);
}

// Stop + WARNING state: red + yellow ON , green off
void setStopTurn() {
  digitalWrite(LED_FORWARD, LOW);
  digitalWrite(LED_STOP, HIGH);
  digitalWrite(LED_WARNING, HIGH);
}

// low battery mode: stop + warning
void setLowBatterySafeMode() {
  digitalWrite(LED_FORWARD, LOW);
  digitalWrite(LED_STOP, HIGH);
  digitalWrite(LED_WARNING, LOW);
}

//                  CLOUD UPLOAD (ThingSpeak)
// field1 distance, field2 state, field3 battery, field4 lowBatt flag
void sendToThingSpeak(float distance, int stateNum, int battPct, int lowBattFlag) {
  // If WiFi is not connected, skip sending (robot still runs locally)
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = String(server) +
               "?api_key=" + apiKey +
               "&field1=" + String(distance, 2) +
               "&field2=" + String(stateNum) +
               "&field3=" + String(battPct) +
               "&field4=" + String(lowBattFlag);

  http.begin(url);
  int httpCode = http.GET();
  http.end();

  Serial.print("ThingSpeak HTTP code: ");
  Serial.println(httpCode);
}

//                    SETUP


void setup() {
  Serial.begin(115200);

  // Configure ultrasonic pins
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Configure LED pins
  pinMode(LED_FORWARD, OUTPUT);
  pinMode(LED_STOP, OUTPUT);
  pinMode(LED_WARNING, OUTPUT);

  // Configure ADC resolution 
  analogReadResolution(12);

  // Connect to WiFi 
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected!");
}

//                  MAIN LOOP


void loop() {
  float d = readDistanceCM();
  int battPct = readBatteryPercent();
  
// Battery power management, If battery is low, we enter safe mode and send an alert to the dashboard
  const int LOW_BATT_THRESHOLD = 20;    
  int lowBattFlag = (battPct <= LOW_BATT_THRESHOLD) ? 1 : 0;

  // 3) Decide robot state based on battery and obstacle distance, 1=forward, 0=stop, includes warning/low batt
  int stateNum;           
  const char* stateText;  

  if (lowBattFlag) {
    // Low battery behavior: stop safely and alert user
    setLowBatterySafeMode();
    stateNum = 0;
    stateText = "LOW_BATT_SAFE";
  } else {
    // Normal obstacle avoidance behavior
    if (d > 0 && d < SAFE_DISTANCE) {
      setStopTurn();
      stateNum = 0;
      stateText = "STOP";
    } else {
      setForward();
      stateNum = 1;
      stateText = "FORWARD";
    }
  }

  // 4) serial output 
  Serial.print("Distance: ");
  Serial.print(d);
  Serial.print(" cm | State: ");
  Serial.print(stateText);
  Serial.print(" (");
  Serial.print(stateNum);
  Serial.print(") | Battery: ");
  Serial.print(battPct);
  Serial.print("% | LowBattFlag: ");
  Serial.println(lowBattFlag);

  // send to cloud every 15s, rate limit + less WiFi usage, "power saving" 
  // This is also a power-management strategy: reducing WiFi transmission frequency
  if (millis() - lastSend >= sendInterval) {
    lastSend = millis();
    sendToThingSpeak(d, stateNum, battPct, lowBattFlag);
  }

  delay(100);
}
